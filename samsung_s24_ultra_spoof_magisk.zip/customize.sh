#!/system/bin/sh
SKIPUNZIP=1

# Display welcome message
ui_print " "
ui_print "**************************************"
ui_print "* Samsung S24 Ultra Spoof Module (Safe) *"
ui_print "* By willygailo01@gmail.com          *"
ui_print "**************************************"
ui_print " "
ui_print "This module will safely spoof your device"
ui_print "as a Samsung Galaxy S24 Ultra!"
ui_print "With Samsung Exynos 2400 processor"
ui_print " "

# Check Android version with prominent warning
ui_print "- Checking device compatibility..."
ui_print "- IMPORTANT: This module REQUIRES Android 10+ -"
android_version=$(getprop ro.build.version.release)
android_sdk=$(getprop ro.build.version.sdk)
if [ "$android_sdk" -lt 29 ]; then
  ui_print "! ---------------------------------------- !"
  ui_print "! INCOMPATIBLE ANDROID VERSION DETECTED    !"
  ui_print "! Unsupported Android version: $android_version (SDK $android_sdk)"
  ui_print "! This module requires Android 10 (SDK 29) or higher"
  ui_print "! Installation aborted for your safety     !"
  ui_print "! ---------------------------------------- !"
  abort
fi

ui_print "✓ Android $android_version detected (SDK $android_sdk) - Compatible"
ui_print "✓ Compatible with Samsung, Infinix, Huawei, Realme, Redmi devices"

# Create backup of original device properties
ui_print "- Creating backup of original device properties"
mkdir -p $MODPATH/backup
getprop > $MODPATH/backup/original_props.txt

# Extract module files
ui_print "- Extracting module files"
unzip -o "$ZIPFILE" -x 'META-INF/*' -d $MODPATH >&2

# Create recovery script
ui_print "- Creating safety recovery script"
cat > $MODPATH/service.sh << EOF
#!/system/bin/sh
# Safe property adjustment script with recovery failsafe
# Wait for system to boot completely
until [ "\$(getprop sys.boot_completed)" = "1" ]; do
  sleep 5
done

# Wait a bit more to ensure all services are started
sleep 10

# Check if we can access Magisk's resetprop
RESETPROP="/data/adb/magisk/resetprop"
if [ ! -f "\$RESETPROP" ]; then
  # Fallback to system resetprop if available
  RESETPROP="resetprop"
fi

# Setup safety timer - will restore original props if system crashes
(
  # Wait to see if the system remains stable
  sleep 300
  # If we reach here, system is stable, delete the recovery flag
  rm -f /data/local/tmp/spoof_recovery_needed
) &

# Set recovery flag - will be deleted if system remains stable
touch /data/local/tmp/spoof_recovery_needed

# Apply properties safely - improved system info compatibility
\$RESETPROP ro.product.model "SM-S928B"
\$RESETPROP ro.product.brand samsung
\$RESETPROP ro.product.name r13qxx
\$RESETPROP ro.product.device r13q
\$RESETPROP ro.product.manufacturer samsung

# Build properties for better app compatibility
\$RESETPROP ro.build.display.id S928BXXU1AWD1
\$RESETPROP ro.build.version.security_patch 2024-05-01
\$RESETPROP ro.build.description "r13qxx-user 14 UP1A.240305.007 S928BXXU1AWD1 release-keys"
\$RESETPROP ro.build.fingerprint "samsung/r13qxx/r13q:14/UP1A.240305.007/S928BXXU1AWD1:user/release-keys"

# System properties - enhanced for app compatibility
\$RESETPROP ro.product.system.model "SM-S928B"
\$RESETPROP ro.product.system.brand samsung
\$RESETPROP ro.product.system.name r13qxx

# Vendor properties - Samsung Exynos processor
\$RESETPROP ro.product.vendor.model "SM-S928B"
\$RESETPROP ro.product.vendor.brand samsung
\$RESETPROP ro.hardware.chipname s5e9935
\$RESETPROP ro.hardware exynos2400
\$RESETPROP ro.soc.manufacturer Samsung
\$RESETPROP ro.soc.model "Exynos 2400"
\$RESETPROP ro.samsung.platform s5e9935
\$RESETPROP ro.vendor.samsung.platform s5e9935

# CPU information enhanced for benchmarks
\$RESETPROP ro.cpu.name "Exynos 2400"
\$RESETPROP ro.cpu.model s5e9935
\$RESETPROP ro.cpu.cores 10
\$RESETPROP ro.chipname s5e9935
\$RESETPROP ro.arch arm64-v8a

# RAM information for system apps
\$RESETPROP ro.boot.hardware.ram 12GB
\$RESETPROP ro.memory.total 12288

# GPU information
\$RESETPROP ro.gpu.name "Xclipse 940"
\$RESETPROP ro.gpu.model "AMD RDNA3"
\$RESETPROP ro.gpu.vendor Samsung
\$RESETPROP ro.opengles.version 196610

# Display properties - safe ones only
\$RESETPROP ro.product.display_name "Galaxy S24 Ultra"
\$RESETPROP ro.product.marketname "Galaxy S24 Ultra"

# Performance properties - carefully selected safe ones
\$RESETPROP debug.performance.tuning 1
\$RESETPROP video.accelerate.hw 1
\$RESETPROP debug.sf.hw 1

# Prevent CPU throttling in benchmarks
\$RESETPROP persist.sys.thermal.mode 1
\$RESETPROP ro.vendor.config.thermal_mode 0

# Samsung security features for improved app compatibility
\$RESETPROP ro.config.knox v30
\$RESETPROP ro.config.tima 1
\$RESETPROP ro.security.keystore.keytype "sakv2,gak"

# If we reach here, initial property setting was successful
# Remove the recovery flag since we've passed the immediate danger zone
rm -f /data/local/tmp/spoof_recovery_needed

exit 0
EOF

# Create recovery service to detect and fix bootloops
cat > $MODPATH/post-fs-data.sh << EOF
#!/system/bin/sh
# Recovery service to detect and fix bootloops

# Double check Android version again for enhanced safety
android_sdk=\$(getprop ro.build.version.sdk)
if [ "\$android_sdk" -lt 29 ]; then
  # Below Android 10, disable the module silently
  touch $MODPATH/disable
  exit 0
fi

# Check if recovery is needed (system crashed before safety timer expired)
if [ -f "/data/local/tmp/spoof_recovery_needed" ]; then
  # System crashed after last attempt - restore original model only
  resetprop ro.product.model "\$(grep "ro.product.model=" $MODPATH/backup/original_props.txt | cut -d= -f2)"
  resetprop ro.product.brand "\$(grep "ro.product.brand=" $MODPATH/backup/original_props.txt | cut -d= -f2)"
  resetprop ro.product.name "\$(grep "ro.product.name=" $MODPATH/backup/original_props.txt | cut -d= -f2)"
  resetprop ro.product.device "\$(grep "ro.product.device=" $MODPATH/backup/original_props.txt | cut -d= -f2)"
  resetprop ro.product.manufacturer "\$(grep "ro.product.manufacturer=" $MODPATH/backup/original_props.txt | cut -d= -f2)"
  resetprop ro.hardware.chipname "\$(grep "ro.hardware.chipname=" $MODPATH/backup/original_props.txt | cut -d= -f2 || echo "")"
  resetprop ro.soc.manufacturer "\$(grep "ro.soc.manufacturer=" $MODPATH/backup/original_props.txt | cut -d= -f2 || echo "")"
  resetprop ro.soc.model "\$(grep "ro.soc.model=" $MODPATH/backup/original_props.txt | cut -d= -f2 || echo "")"
  
  # Create a flag file to indicate safe mode is active
  touch $MODPATH/safe_mode_active
fi

exit 0
EOF

# Set permissions
ui_print "- Setting permissions"
set_perm_recursive $MODPATH 0 0 0755 0644
set_perm $MODPATH/system.prop 0 0 0600
set_perm $MODPATH/module.sh 0 0 0755
set_perm $MODPATH/service.sh 0 0 0755
set_perm $MODPATH/post-fs-data.sh 0 0 0755

ui_print "- Installation completed with safety features!"
ui_print "- Device will spoof as Galaxy S24 Ultra with Samsung Exynos processor"
ui_print "- System information, benchmarks and apps should now work better"
ui_print "- IMPORTANT: This module requires Android 10 (SDK 29) or above"
ui_print "- Reboot your device to apply changes"
ui_print "- This safe version has anti-bootloop protection" 