#!/system/bin/sh
# Do not remove this line
MODDIR=${0%/*}

# Safety check - exit if we detect any issues
SAFETY_CHECK=$(getprop ro.build.version.sdk)
if [ "$SAFETY_CHECK" -lt 29 ]; then
  # Below Android 10, abort silently to prevent issues
  log -t "SpoofS24Ultra" "Error: Unsupported Android version (SDK $SAFETY_CHECK), below required SDK 29 (Android 10)"
  # Create a flag file to indicate incompatible version
  touch $MODDIR/incompatible_android_version
  # Disable module
  touch $MODDIR/disable
  exit 0
fi

# Log successful execution
log -t "SpoofS24Ultra" "Module running on compatible Android version: SDK $SAFETY_CHECK (Android 10+)"

# Additional post-fs-data operations can be added here
# This script will be executed in post-fs-data mode 